// OpenCVApplication.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "common.h"
#include <iostream>
#include <fstream>

using namespace cv;
using namespace std;


void testOpenImage()
{
	char fname[MAX_PATH];
	while(openFileDlg(fname))
	{
		Mat src;
		src = imread(fname);
		imshow("image",src);
		waitKey();
	}
}

void testOpenImagesFld()
{
	char folderName[MAX_PATH];
	if (openFolderDlg(folderName)==0)
		return;
	char fname[MAX_PATH];
	FileGetter fg(folderName,"bmp");
	while(fg.getNextAbsFile(fname))
	{
		Mat src;
		src = imread(fname);
		imshow(fg.getFoundFileName(),src);
		if (waitKey()==27) //ESC pressed
			break;
	}
}

void testImageOpenAndSave()
{
	Mat src, dst;

	src = imread("Images/Lena_24bits.bmp", IMREAD_COLOR);	// Read the image

	if (!src.data)	// Check for invalid input
	{
		printf("Could not open or find the image\n");
		return;
	}

	// Get the image resolution
	Size src_size = Size(src.cols, src.rows);

	// Display window
	const char* WIN_SRC = "Src"; //window for the source image
	namedWindow(WIN_SRC, WINDOW_AUTOSIZE);
	moveWindow(WIN_SRC, 0, 0);

	const char* WIN_DST = "Dst"; //window for the destination (processed) image
	namedWindow(WIN_DST, WINDOW_AUTOSIZE);
	moveWindow(WIN_DST, src_size.width + 10, 0);

	cvtColor(src, dst, COLOR_BGR2GRAY); //converts the source image to a grayscale one

	imwrite("Images/Lena_24bits_gray.bmp", dst); //writes the destination to file

	imshow(WIN_SRC, src);
	imshow(WIN_DST, dst);

	printf("Press any key to continue ...\n");
	waitKey(0);
}

void testNegativeImage()
{
	char fname[MAX_PATH];
	while(openFileDlg(fname))
	{
		double t = (double)getTickCount(); // Get the current time [s]
		
		Mat src = imread(fname,IMREAD_GRAYSCALE);
		int height = src.rows;
		int width = src.cols;
		Mat dst = Mat(height,width,CV_8UC1);
		// Asa se acceseaaza pixelii individuali pt. o imagine cu 8 biti/pixel
		// Varianta ineficienta (lenta)
		for (int i=0; i<height; i++)
		{
			for (int j=0; j<width; j++)
			{
				uchar val = src.at<uchar>(i,j);
				uchar neg = 255 - val;
				dst.at<uchar>(i,j) = neg;
			}
		}

		// Get the current time again and compute the time difference [s]
		t = ((double)getTickCount() - t) / getTickFrequency();
		// Print (in the console window) the processing time in [ms] 
		printf("Time = %.3f [ms]\n", t * 1000);

		imshow("input image",src);
		imshow("negative image",dst);
		waitKey();
	}
}

void testParcurgereSimplaDiblookStyle()
{
	char fname[MAX_PATH];
	while (openFileDlg(fname))
	{
		Mat src = imread(fname, IMREAD_GRAYSCALE);
		int height = src.rows;
		int width = src.cols;
		Mat dst = src.clone();

		double t = (double)getTickCount(); // Get the current time [s]

		// the fastest approach using the �diblook style�
		uchar *lpSrc = src.data;
		uchar *lpDst = dst.data;
		int w = (int) src.step; // no dword alignment is done !!!
		for (int i = 0; i<height; i++)
			for (int j = 0; j < width; j++) {
				uchar val = lpSrc[i*w + j];
				lpDst[i*w + j] = 255 - val;
			}

		// Get the current time again and compute the time difference [s]
		t = ((double)getTickCount() - t) / getTickFrequency();
		// Print (in the console window) the processing time in [ms] 
		printf("Time = %.3f [ms]\n", t * 1000);

		imshow("input image",src);
		imshow("negative image",dst);
		waitKey();
	}
}

void testColor2Gray()
{
	char fname[MAX_PATH];
	while(openFileDlg(fname))
	{
		Mat src = imread(fname);

		int height = src.rows;
		int width = src.cols;

		Mat dst = Mat(height,width,CV_8UC1);

		// Asa se acceseaaza pixelii individuali pt. o imagine RGB 24 biti/pixel
		// Varianta ineficienta (lenta)
		for (int i=0; i<height; i++)
		{
			for (int j=0; j<width; j++)
			{
				Vec3b v3 = src.at<Vec3b>(i,j);
				uchar b = v3[0];
				uchar g = v3[1];
				uchar r = v3[2];
				dst.at<uchar>(i,j) = (r+g+b)/3;
			}
		}
		
		imshow("input image",src);
		imshow("gray image",dst);
		waitKey();
	}
}

void testBGR2HSV()
{
	char fname[MAX_PATH];
	while (openFileDlg(fname))
	{
		Mat src = imread(fname);
		int height = src.rows;
		int width = src.cols;

		// Componentele d eculoare ale modelului HSV
		Mat H = Mat(height, width, CV_8UC1);
		Mat S = Mat(height, width, CV_8UC1);
		Mat V = Mat(height, width, CV_8UC1);

		// definire pointeri la matricele (8 biti/pixeli) folosite la afisarea componentelor individuale H,S,V
		uchar* lpH = H.data;
		uchar* lpS = S.data;
		uchar* lpV = V.data;

		Mat hsvImg;
		cvtColor(src, hsvImg, COLOR_BGR2HSV);

		// definire pointer la matricea (24 biti/pixeli) a imaginii HSV
		uchar* hsvDataPtr = hsvImg.data;

		for (int i = 0; i<height; i++)
		{
			for (int j = 0; j<width; j++)
			{
				int hi = i*width * 3 + j * 3;
				int gi = i*width + j;

				lpH[gi] = hsvDataPtr[hi] * 510 / 360;		// lpH = 0 .. 255
				lpS[gi] = hsvDataPtr[hi + 1];			// lpS = 0 .. 255
				lpV[gi] = hsvDataPtr[hi + 2];			// lpV = 0 .. 255
			}
		}

		imshow("input image", src);
		imshow("H", H);
		imshow("S", S);
		imshow("V", V);

		waitKey();
	}
}

void testResize()
{
	char fname[MAX_PATH];
	while(openFileDlg(fname))
	{
		Mat src;
		src = imread(fname);
		Mat dst1,dst2;
		//without interpolation
		resizeImg(src,dst1,320,false);
		//with interpolation
		resizeImg(src,dst2,320,true);
		imshow("input image",src);
		imshow("resized image (without interpolation)",dst1);
		imshow("resized image (with interpolation)",dst2);
		waitKey();
	}
}

void testCanny()
{
	char fname[MAX_PATH];
	while(openFileDlg(fname))
	{
		Mat src,dst,gauss;
		src = imread(fname,IMREAD_GRAYSCALE);
		double k = 0.4;
		int pH = 50;
		int pL = (int) k*pH;
		GaussianBlur(src, gauss, Size(5, 5), 0.8, 0.8);
		Canny(gauss,dst,pL,pH,3);
		imshow("input image",src);
		imshow("canny",dst);
		waitKey();
	}
}

void testVideoSequence()
{
	VideoCapture cap("Videos/rubic.avi"); // off-line video from file
	//VideoCapture cap(0);	// live video from web cam
	if (!cap.isOpened()) {
		printf("Cannot open video capture device.\n");
		waitKey(0);
		return;
	}
		
	Mat edges;
	Mat frame;
	char c;

	while (cap.read(frame))
	{
		Mat grayFrame;
		cvtColor(frame, grayFrame, COLOR_BGR2GRAY);
		Canny(grayFrame,edges,40,100,3);
		imshow("source", frame);
		imshow("gray", grayFrame);
		imshow("edges", edges);
		c = waitKey(0);  // waits a key press to advance to the next frame
		if (c == 27) {
			// press ESC to exit
			printf("ESC pressed - capture finished\n"); 
			break;  //ESC pressed
		};
	}
}


void testSnap()
{
	VideoCapture cap(0); // open the deafult camera (i.e. the built in web cam)
	if (!cap.isOpened()) // openenig the video device failed
	{
		printf("Cannot open video capture device.\n");
		return;
	}

	Mat frame;
	char numberStr[256];
	char fileName[256];
	
	// video resolution
	Size capS = Size((int)cap.get(CAP_PROP_FRAME_WIDTH),
		(int)cap.get(CAP_PROP_FRAME_HEIGHT));

	// Display window
	const char* WIN_SRC = "Src"; //window for the source frame
	namedWindow(WIN_SRC, WINDOW_AUTOSIZE);
	moveWindow(WIN_SRC, 0, 0);

	const char* WIN_DST = "Snapped"; //window for showing the snapped frame
	namedWindow(WIN_DST, WINDOW_AUTOSIZE);
	moveWindow(WIN_DST, capS.width + 10, 0);

	char c;
	int frameNum = -1;
	int frameCount = 0;

	for (;;)
	{
		cap >> frame; // get a new frame from camera
		if (frame.empty())
		{
			printf("End of the video file\n");
			break;
		}

		++frameNum;
		
		imshow(WIN_SRC, frame);

		c = waitKey(10);  // waits a key press to advance to the next frame
		if (c == 27) {
			// press ESC to exit
			printf("ESC pressed - capture finished");
			break;  //ESC pressed
		}
		if (c == 115){ //'s' pressed - snapp the image to a file
			frameCount++;
			fileName[0] = NULL;
			sprintf(numberStr, "%d", frameCount);
			strcat(fileName, "Images/A");
			strcat(fileName, numberStr);
			strcat(fileName, ".bmp");
			bool bSuccess = imwrite(fileName, frame);
			if (!bSuccess) 
			{
				printf("Error writing the snapped image\n");
			}
			else
				imshow(WIN_DST, frame);
		}
	}

}

void MyCallBackFunc(int event, int x, int y, int flags, void* param)
{
	//More examples: http://opencvexamples.blogspot.com/2014/01/detect-mouse-clicks-and-moves-on-image.html
	Mat* src = (Mat*)param;
	if (event == EVENT_LBUTTONDOWN)
		{
			printf("Pos(x,y): %d,%d  Color(RGB): %d,%d,%d\n",
				x, y,
				(int)(*src).at<Vec3b>(y, x)[2],
				(int)(*src).at<Vec3b>(y, x)[1],
				(int)(*src).at<Vec3b>(y, x)[0]);
		}
}

void testMouseClick()
{
	Mat src;
	// Read image from file 
	char fname[MAX_PATH];
	while (openFileDlg(fname))
	{
		src = imread(fname);
		//Create a window
		namedWindow("My Window", 1);

		//set the callback function for any mouse event
		setMouseCallback("My Window", MyCallBackFunc, &src);

		//show the image
		imshow("My Window", src);

		// Wait until user press some key
		waitKey(0);
	}
}

/* Histogram display function - display a histogram using bars (simlilar to L3 / PI)
Input:
name - destination (output) window name
hist - pointer to the vector containing the histogram values
hist_cols - no. of bins (elements) in the histogram = histogram image width
hist_height - height of the histogram image
Call example:
showHistogram ("MyHist", hist_dir, 255, 200);
*/
void showHistogram(const std::string& name, int* hist, const int  hist_cols, const int hist_height)
{
	Mat imgHist(hist_height, hist_cols, CV_8UC3, CV_RGB(255, 255, 255)); // constructs a white image

	//computes histogram maximum
	int max_hist = 0;
	for (int i = 0; i<hist_cols; i++)
	if (hist[i] > max_hist)
		max_hist = hist[i];
	double scale = 1.0;
	scale = (double)hist_height / max_hist;
	int baseline = hist_height - 1;

	for (int x = 0; x < hist_cols; x++) {
		Point p1 = Point(x, baseline);
		Point p2 = Point(x, baseline - cvRound(hist[x] * scale));
		line(imgHist, p1, p2, CV_RGB(255, 0, 255)); // histogram bins colored in magenta
	}

	imshow(name, imgHist);
}


//Proiect PI

bool isInside(Mat img, int i, int j) {

	int height = img.rows;
	int width = img.cols;

	if (0 <= i && i <= height) {
		if (0 <= j && j <= width) {
			return true;
		}
	}

	return false;
}

Mat grayscale_function(Mat src) {
	int height = src.rows;
	int width = src.cols;
	Mat dst = Mat(height, width, CV_8UC1); 

	for (int i = 0; i < height; i++)
	{
		for (int j = 0; j < width; j++)
		{
			Vec3b pixel = src.at< Vec3b>(i, j);
			uchar B = pixel[0];
			uchar G = pixel[1];
			uchar R = pixel[2];

			float var = (float)(R + G + B) / 3; //media aritmetica

			dst.at<uchar>(i, j) = var;
		}
	}

	return dst;
}

Mat gaussian_function(Mat src) { //nu cred ca e nevoie de asta
	int height = src.rows;
	int width = src.cols;
	Mat dst = Mat(height, width, CV_8UC1);

	GaussianBlur(src, dst, Size(5, 5), 0.8, 0.8);
	return dst;
}

Mat binary_imag_function(Mat src) {
	int height = src.rows;
	int width = src.cols;
	Mat dst = Mat(height, width, CV_8UC1);


	for (int i = 0; i < height; i++)
	{
		for (int j = 0; j < width; j++)
		{
			uchar val = src.at<uchar>(i, j);
			if (val < 128) //ce e mai mic, negru -- restul alb
				dst.at<uchar>(i, j) = 0;
			else
				dst.at<uchar>(i, j) = 255;

		}
	}

	return dst;
}

Mat auto_binary_imag_function(Mat src) {
	int min = 256;
	int max = 0;
	float T, T2 = 0.0f;
	float deviatia = 0, media1 = 0, media2 = 0, pixeli = 0, pixeli2 = 0;
	int N1 = 0, N2 = 0;
	int h[256] = {};

	int height = src.rows;
	int width = src.cols;
	Mat dst = Mat(height, width, CV_8UC1, Scalar(255));


	for (int i = 0; i < src.rows; i++) {
		for (int j = 0; j < src.cols; j++) {
			h[src.at<uchar>(i, j)]++;
			if (src.at<uchar>(i, j) < min)
				min = src.at<uchar>(i, j);
			if (src.at<uchar>(i, j) > max)
				max = src.at<uchar>(i, j);
		}
	}

	T = (min + max) / 2;

	while (abs(T - T2) >= 0.1) {

		T2 = T;

		media1 = 0;
		media2 = 0;
		N1 = 0;
		N2 = 0;

		for (int i = min; i < T; i++) {
			media1 += i * h[i];
			N1 += h[i];
		}
		for (int i = T + 1; i <= max; i++) {
			media2 += i * h[i];
			N2 += h[i];
		}
		media1 /= N1;
		media2 /= N2;


		T = (media1 + media2) / 2;
	}
	for (int i = 0; i < src.rows; i++) {
		for (int j = 0; j < src.cols; j++) {
			if (src.at<uchar>(i, j) <= T)
				dst.at<uchar>(i, j) = 0;
			else
				dst.at<uchar>(i, j) = 255;
		}
	}

	return dst;
}

Mat dilatare_function(Mat src) {
	Mat dst(src.rows, src.cols, CV_8UC1, Scalar(255));

	int di[8] = { -1, -1, -1, 0, 0, 1, 1, 1 };
	int dj[8] = { -1, 0, 1, -1, 1, -1, 0, 1 };

	for (int i = 1; i < src.rows - 1; i++) {
		for (int j = 1; j < src.cols - 1; j++) {
			uchar val = src.at<uchar>(i, j);
			if (val == 0) { //daca e pixel obiect
				for (int k = 0; k < 8; k++) { //pixelii din vecinatate devin pixeli obiect
					dst.at<uchar>(i + di[k], j + dj[k]) = 0;
				}
			}
		}
	}

	return dst;
}

Mat eroziune_function(Mat src) {
	Mat dst(src.rows, src.cols, CV_8UC1, Scalar(255));

	int di[8] = { -1,-1,-1, 0, 0, 1,1,1 };
	int dj[8] = { -1, 0, 1, -1, 1, -1, 0, 1 };

	for (int i = 1; i < src.rows - 1; i++) {
		for (int j = 1; j < src.cols - 1; j++) {
			uchar val = src.at<uchar>(i, j);
			if (val == 0) {
				bool gasit = true;
				for (int k = 0; k < 8; k++) {
					if (isInside(src, i + di[k], j + dj[k])) {
						if (src.at<uchar>(i + di[k], j + dj[k]) == 255)
							gasit = false;
					}

				}

				if (gasit) {
					dst.at<uchar>(i, j) = 0;
				}
			}
		}
	}

	return dst;
}

Mat inchidere_function(Mat src) {
	Mat dst1(src.rows, src.cols, CV_8UC1, Scalar(255));
	Mat dst2(src.rows, src.cols, CV_8UC1, Scalar(255));

	dst1 = dilatare_function(src);
	dst2 = eroziune_function(dst1);

	return dst2;
}

Mat dilatare_n_function(Mat src, int n) {

	int di[8] = { -1, -1,-1, 0, 0, 1, 1, 1 };
	int dj[8] = { -1, 0, 1, -1, 1, -1, 0, 1 };

	Mat dst1(src.rows, src.cols, CV_8UC1, Scalar(255));
	Mat dst2(src.rows, src.cols, CV_8UC1, Scalar(255));
	dst2 = src.clone();
	dst1 = src.clone();

	for (int m = 0; m < n; m++) {
		for (int i = 1; i < src.rows - 1; i++) {
			for (int j = 1; j < src.cols - 1; j++) {
				uchar val = dst2.at<uchar>(i, j);
				if (val == 0) { //daca e pixel obiect
					for (int k = 0; k < 8; k++) { //pixelii din vecinatate devin pixeli obiect
						dst1.at<uchar>(i + di[k], j + dj[k]) = 0;
					}
				}
			}
		}
		dst2 = dst1.clone();
	}

	return dst1;

}

Mat eroziune_n_function(Mat src, int n) {
	int di[8] = { -1,-1,-1, 0, 0, 1,1,1 };
	int dj[8] = { -1, 0, 1, -1, 1, -1, 0, 1 };

	Mat dst1(src.rows, src.cols, CV_8UC1, Scalar(255));
	Mat dst2(src.rows, src.cols, CV_8UC1, Scalar(255));
	dst2 = src.clone();
	dst1 = src.clone();

	for (int m = 0; m < n; m++) {
		for (int i = 1; i < src.rows - 1; i++) {
			for (int j = 1; j < src.cols - 1; j++) {
				uchar val = dst2.at<uchar>(i, j);
				if (val == 255) { //daca e pixel fundal
					for (int k = 0; k < 8; k++) { //pixelii din vecinatate devin pixeli obiect
						dst1.at<uchar>(i + di[k], j + dj[k]) = 255;
					}
				}
			}
		}
		dst2 = dst1.clone();
	}

	return dst1;
}

Mat umplere_regiuni_function(Mat src) {
	int height = src.rows;
	int width = src.cols;
	Mat dst = Mat(height, width, CV_8UC1, Scalar(255));

	dst.at<uchar>(height / 2, width / 2) = 0;

	Mat aux;
	bool ok;
	//int di[4] = { 0, -1, 0, 1 };
	//int dj[4] = { 1, 0, -1, 0 };

	int di[4] = { -1, 0, 1, 0 };
	int dj[4] = { 0, -1, 0, 1 };

	do {
		dst.copyTo(aux);

		ok = true;
		for (int i = 1; i < height - 1; i++)
		{
			for (int j = 1; j < width - 1; j++)
			{
				if (dst.at<uchar>(i, j) == 0)
				{
					for (int k = 0; k < 4; k++)
					{
						if (aux.at<uchar>(i + di[k], j + dj[k]) != 0 && src.at<uchar>(i + di[k], j + dj[k]) != 0) {
							aux.at<uchar>(i + di[k], j + dj[k]) = 0;
							ok = false;
						}
					}

				}
			}
		}
		aux.copyTo(dst);

	} while (!ok);

	for (int i = 1; i < height - 1; i++)
	{
		for (int j = 1; j < width - 1; j++)
		{
			if (src.at<uchar>(i, j) == 0) {
				dst.at<uchar>(i, j) = 0;
			}
		}
	}

	return dst;
} 

Mat canny_function(Mat src) {
	int height = src.rows;
	int width = src.cols;
	Mat dst = Mat(height, width, CV_8UC1);

	double k = 0.4;
	int pH = 700;
	int pL = (int)k * pH;
	Canny(src, dst, pL, pH, 3);

	return dst;
}

Mat dilatare_contur_function(Mat src) {
	Mat dst(src.rows, src.cols, CV_8UC1, Scalar(0));

	int di[8] = { -1, -1, -1, 0, 0, 1, 1, 1 };
	int dj[8] = { -1, 0, 1, -1, 1, -1, 0, 1 };


	for (int i = 1; i < src.rows - 1; i++) {
		for (int j = 1; j < src.cols - 1; j++) {
			uchar val = src.at<uchar>(i, j);
			if (val == 255) { 
				for (int k = 0; k < 8; k++) { 
					dst.at<uchar>(i + di[k], j + dj[k]) = 255;
				}
			}
		}
	}

	return dst;
}

RNG rng(12345);

Mat colorare_contur_funtion(Mat src) { 

	vector<vector<Point>> contours;
	vector<Vec4i> hierarchy;
	findContours(src, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE);
	Mat drawing = Mat::zeros(src.size(), CV_8UC3);
	for (size_t i = 0; i < contours.size(); i++)
	{
		Scalar color = Scalar(rng.uniform(0, 256), rng.uniform(0, 256), rng.uniform(0, 256)); 
		drawContours(drawing, contours, (int)i, color, 2, LINE_8, hierarchy, 0);
	}

	return drawing;
}

vector<vector<Point>> contours;

Mat filtrare_contur_function(Mat src) { 
	vector<Vec4i> hierarchy;
	findContours(src, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE);
	Mat drawing = Mat::zeros(src.size(), CV_8UC3);
	double sumContour = 0;
	int count = 0;

	/*
	for (size_t i = 0; i < contours.size(); i++) {
		if (fabs(cv::contourArea(contours[i])) > 50) {
			sumContour += fabs(cv::contourArea(contours[i]));
			count++;
		}
			
	}

	sumContour = sumContour / count;
	cout << "Suntem aici " << sumContour << " ";
	*/

	for (size_t i = 0; i < contours.size(); i++) {
		double contourArea = fabs(cv::contourArea(contours[i]));
		cout << contourArea << " ";
		if (contourArea < 16000) {
			continue;
		}

		Scalar color = Scalar(rng.uniform(0, 256), rng.uniform(0, 256), rng.uniform(0, 256));
		drawContours(drawing, contours, (int)i, color, 2, LINE_8, hierarchy, 0);

	}

	return drawing;
}

Mat detect_draw_contour_function(Mat &src) {
	vector<vector<Point>> contours_poly(contours.size());
	vector<Rect> boundRect(contours.size());
	vector<Point2f> centers(contours.size());
	vector<float> radius(contours.size());

	for (size_t i = 0; i < contours.size(); i++) {
		double contourArea = fabs(cv::contourArea(contours[i]));
		if (contourArea < 16000) {
			continue;
		}

		approxPolyDP(contours[i], contours_poly[i], 3, true);
		boundRect[i] = boundingRect(contours_poly[i]);
		minEnclosingCircle(contours_poly[i], centers[i], radius[i]);
	}

	Mat drawing = Mat::zeros(src.size(), CV_8UC3);

	for (size_t i = 0; i < contours.size(); i++) {
		Scalar color = Scalar(rng.uniform(0, 256), rng.uniform(0, 256), rng.uniform(0, 256));
		rectangle(drawing, boundRect[i].tl(), boundRect[i].br(), color, 1);
	}


	return drawing;
}


void proiect() {
	char fname[MAX_PATH];
	if (openFileDlg(fname))
	{
		Mat src = imread(fname, IMREAD_COLOR);
		int height = src.rows;
		int width = src.cols;
		Mat imagGrayscale = Mat(height, width, CV_8UC1);
		Mat imagGaussian = Mat(height, width, CV_8UC1); //doar blureaza
		Mat imagBinary = Mat(height, width, CV_8UC1);
		Mat imagInchidere = Mat(height, width, CV_8UC1);
		Mat imagDilatare = Mat(height, width, CV_8UC1);
		Mat imagEroziune = Mat(height, width, CV_8UC1);
		Mat imagUmplereRegiuni = Mat(height, width, CV_8UC1);
		Mat imagCanny = Mat(height, width, CV_8UC1);
		Mat imagDilatContur = Mat(height, width, CV_8UC1);
		Mat imagContureColor = Mat(height, width, CV_8UC3);
		Mat imagFiltrareContur = Mat(height, width, CV_8UC3);
		Mat imagIncadrare = Mat(height, width, CV_8UC3);

		imagGrayscale = grayscale_function(src);
		//imagGaussian = gaussian_function(imagGrayscale);
		//imagBinary = binary_imag_function(imagGrayscale);
		imagBinary = auto_binary_imag_function(imagGrayscale);
		imagInchidere = inchidere_function(imagBinary);
		//imagUmplereRegiuni = umplere_regiuni_function(imagInchidere);
		imagDilatare = dilatare_n_function(imagInchidere, 15);
		imagCanny = canny_function(imagDilatare);
		imagDilatContur = dilatare_contur_function(imagCanny);
		imagContureColor = colorare_contur_funtion(imagDilatContur);
		imagFiltrareContur = filtrare_contur_function(imagDilatContur); //poate la filtrare contur se mai poate lucra
		imagIncadrare = detect_draw_contour_function(src);

		double alpha = 0.5;
		Mat imagFinal;
		addWeighted(src, alpha, imagIncadrare, 1 - alpha, 0, imagFinal);
		

		imshow("input image", src);
		imshow("grayscale image", imagGrayscale);
		//imshow("gaussian image", imagGaussian);
		imshow("binary image", imagBinary);
		imshow("inchidere image", imagInchidere);
		//imshow("umplere regiuni image", imagUmplereRegiuni);
		imshow("dilatare image", imagDilatare);
		imshow("canny image", imagCanny);
		imshow("dilatare contur image", imagDilatContur);
		imshow("colorare contur image", imagContureColor);
		imshow("filtrare contur image", imagFiltrareContur);
		imshow("incadrare image", imagIncadrare);
		imshow("output image", imagFinal);
		waitKey();
	}
}




int main()
{
	int op;
	do
	{
		system("cls");
		destroyAllWindows();
		printf("Menu:\n");
		printf(" 1 - Open image\n");
		printf(" 2 - Open BMP images from folder\n");
		printf(" 3 - Image negative - diblook style\n");
		printf(" 4 - BGR->HSV\n");
		printf(" 5 - Resize image\n");
		printf(" 6 - Canny edge detection\n");
		printf(" 7 - Edges in a video sequence\n");
		printf(" 8 - Snap frame from live video\n");
		printf(" 9 - Mouse callback demo\n");
		printf(" 10 - Proiect\n");
		printf(" 0 - Exit\n\n");
		printf("Option: ");
		scanf("%d",&op);
		switch (op)
		{
			case 1:
				testOpenImage();
				break;
			case 2:
				testOpenImagesFld();
				break;
			case 3:
				testParcurgereSimplaDiblookStyle(); //diblook style
				break;
			case 4:
				//testColor2Gray();
				testBGR2HSV();
				break;
			case 5:
				testResize();
				break;
			case 6:
				testCanny();
				break;
			case 7:
				testVideoSequence();
				break;
			case 8:
				testSnap();
				break;
			case 9:
				testMouseClick();
				break;
			case 10:
				proiect();
				break;
		}
	}
	while (op!=0);
	return 0;
}